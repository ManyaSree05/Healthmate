const express = require('express');
const mysql = require('mysql2');

const session = require('express-session');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// ✅ Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true
}));

const expressLayouts = require('express-ejs-layouts');
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('layout', 'partials/layout');

// ✅ MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Daddy#123',
  database: 'healthmate'
});

db.connect((err) => {
  if (err) {
    console.error('MySQL connection error:', err);
    return;
  }
  console.log('MySQL connected ✅');
});
app.locals.db = db;

function queryAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    con.query(sql, params, (error, results) => {
      if (error) return reject(error);
      resolve(results);
    });
  });
}



// ✅ Routes

// Home redirect
app.get('/', (req, res) => {
  res.redirect('/login');
});


// Register
app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  const sql = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
  db.query(sql, [username, email, hashed], (err, result) => {
    if (err) {
      console.error('Error inserting user:', err);
      return res.send('Registration failed');
    }
    res.redirect('/login');
  });
});

// Login
app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
    if (err) {
      console.error('Login error:', err);
      return res.send('Login failed');
    }
    if (results.length === 0) return res.send('No user found');

    const match = await bcrypt.compare(password, results[0].password);
    if (match) {
      req.session.user = results[0];
      res.redirect('/accounts');
    } else {
      res.send('Incorrect password');
    }
  });
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// ✅ Age and Category
function calculateAgeAndCategory(dob) {
  const birthDate = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }

  let category = "self";
  if (age <= 3) category = "baby";
  else if (age >= 60) category = "elder";

  return { age, category };
}

// ✅ Accounts View
app.get('/accounts', (req, res) => {
  if (!req.session.user) return res.redirect('/login');

  const sql = 'SELECT * FROM accounts WHERE user_id = ?';
  db.query(sql, [req.session.user.id], (err, results) => {
    if (err) {
      console.error('Fetching accounts failed:', err);
      return res.send('Error loading accounts');
    }
    res.render('accounts', { accounts: results, user: req.session.user });
  });
});

// ✅ Add Account
app.post('/accounts', (req, res) => {
  const { name, dob, gender, blood_group } = req.body;
  const { age, category } = calculateAgeAndCategory(dob);
  const sql = 'INSERT INTO accounts (user_id, name, dob, age, gender, blood_group, category) VALUES (?, ?, ?, ?, ?, ?, ?)';
  db.query(sql, [req.session.user.id, name, dob, age, gender, blood_group, category], (err, result) => {
    if (err) {
      console.error('Error adding account:', err);
      return res.send('Error creating account');
    }
    res.redirect('/accounts');
  });
});

// ✅ Account Dashboard
app.get('/accounts/:id', (req, res) => {
  const accId = req.params.id;
  const sql = 'SELECT * FROM accounts WHERE id = ? AND user_id = ?';
  db.query(sql, [accId, req.session.user.id], (err, results) => {
    if (err) {
      console.error('Error loading account dashboard:', err);
      return res.send('Account not found');
    }
    if (results.length === 0) return res.send("Unauthorized or invalid account");

    const account = results[0];
    res.render('account_dashboard', { account });
  });
});

// ✅ Multer PDF Upload Config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const dir = 'uploads';
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

// ✅ View and Upload Documents
app.get('/accounts/:id/documents', (req, res) => {
  const accountId = req.params.id;
  const sql = 'SELECT * FROM documents WHERE account_id = ?';
  db.query(sql, [accountId], (err, docs) => {
    if (err) {
      console.error('Fetching documents failed:', err);
      return res.send('Could not load documents');
    }
    res.render('upload_documents', { accountId, docs });
  });
});

app.post('/accounts/:id/documents', upload.single('document'), (req, res) => {
  const accountId = req.params.id;
  const file = req.file;

  if (!file) return res.send('No file uploaded.');

  const sql = 'INSERT INTO documents (account_id, file_name) VALUES (?, ?)';
  db.query(sql, [accountId, file.filename], (err, result) => {
    if (err) {
      console.error('Document upload failed:', err);
      return res.send('Upload error');
    }
    res.redirect(`/accounts/${accountId}/documents`);
  });
});

// ✅ Start Server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
// Show self tracker page
app.get('/accounts/:id/self-tracker', (req, res) => {
    const accountId = req.params.id;
    const sql = 'SELECT * FROM self_tracker WHERE account_id = ? ORDER BY created_at DESC';
  
    db.query(sql, [accountId], (err, results) => {
      if (err) throw err;
      res.render('self_tracker', { accountId, entries: results });
    });
  });
  
  // Handle self tracker form submission
  app.post('/accounts/:id/self-tracker', (req, res) => {
    const accountId = req.params.id;
    const { exercise, duration, meditation, sleep, screen_time, notes } = req.body;
  
    const sql = `
      INSERT INTO self_tracker (account_id, exercise, duration, meditation, sleep, screen_time, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    db.query(sql, [accountId, exercise, duration, meditation, sleep, screen_time, notes], (err) => {
      if (err) throw err;
      res.redirect(`/accounts/${accountId}/self-tracker`);
    });
  });
// GET form and show previous self health data
app.get('/accounts/:id/self_health', (req, res) => {
    const accId = req.params.id;
    const sql = 'SELECT * FROM self_health WHERE account_id = ? ORDER BY created_at DESC';
    db.query(sql, [accId], (err, results) => {
      if (err) throw err;
      res.render('self_health', { accountId: accId, records: results });
    });
  });
  
  // POST self health details
  app.post('/accounts/:id/self_health', (req, res) => {
    const accId = req.params.id;
    const { basic, special, medications } = req.body;
    const sql = 'INSERT INTO self_health (account_id, basic, special, medications) VALUES (?, ?, ?, ?)';
    db.query(sql, [accId, basic, special, medications], (err, result) => {
      if (err) throw err;
      res.redirect(`/accounts/${accId}/self_health`);
    });
  });
  // Show form
app.get('/self-health-info', (req, res) => {
    if (!req.session.user) return res.redirect('/login');
    res.render('self_health_info');
  });
  
  // Handle submission
  app.post('/self-health-info', (req, res) => {
    const userId = req.session.user.id;
    const {
      bp, sugar, height_cm, weight_kg, blood_group, allergies, eyesight,
      condition, description, diagnosed_on,
      medication_name, dosage, frequency, reminder_time
    } = req.body;
  
    const basicSQL = `INSERT INTO basic_health (user_id, bp, sugar, height_cm, weight_kg, blood_group, allergies, eyesight) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
    const specialSQL = `INSERT INTO special_conditions (user_id, condition1, description, diagnosed_on) 
                        VALUES (?, ?, ?, ?)`;
    const medSQL = `INSERT INTO current_medications (user_id, medication_name, dosage, frequency, reminder_time) 
                    VALUES (?, ?, ?, ?, ?)`;
  
    db.query(basicSQL, [userId, bp, sugar, height_cm, weight_kg, blood_group, allergies, eyesight], (err1) => {
      if (err1) throw err1;
      db.query(specialSQL, [userId, condition, description, diagnosed_on], (err2) => {
        if (err2) throw err2;
        db.query(medSQL, [userId, medication_name, dosage, frequency, reminder_time], (err3) => {
          if (err3) throw err3;
          res.redirect('/self-health-info/view');
        });
      });
    });
  });
  
  // View data
  app.get('/self-health-info/view', (req, res) => {
    const userId = req.session.user.id;
    const sql1 = 'SELECT * FROM basic_health WHERE user_id = ? ORDER BY created_at DESC';
    const sql2 = 'SELECT * FROM special_conditions WHERE user_id = ? ORDER BY created_at DESC';
    const sql3 = 'SELECT * FROM current_medications WHERE user_id = ? ORDER BY created_at DESC';
  
    db.query(sql1, [userId], (err1, basicData) => {
      if (err1) throw err1;
      db.query(sql2, [userId], (err2, specialData) => {
        if (err2) throw err2;
        db.query(sql3, [userId], (err3, medsData) => {
          if (err3) throw err3;
          res.render('view_self_health_info', {
            basicData,
            specialData,
            medsData
          });
        });
      });
    });
  });
require('./cron/medicationReminder');
// Self Health Main Dashboard (optional)
app.get('/self-health', (req, res) => {
  res.render('self/self_dashboard');
});

// Basic Health Info
app.get('/self-health/basic', (req, res) => {
  res.render('self/basic_info');
});
app.post('/self-health/basic', (req, res) => {
  const { bp, sugar, height_cm, weight_kg, blood_group, allergies, eyesight } = req.body;
  // Save to DB
  res.redirect('/self-health/basic');
});

// Special Health Conditions
app.get('/self-health/conditions', (req, res) => {
  res.render('self/special_conditions');
});
app.post('/self-health/conditions', (req, res) => {
  const { condition1, description, diagnosed_on } = req.body;
  const diagnosedDate = diagnosed_on || null;
  const condition = condition1 || 'Not specified';

  if (!diagnosedDate || diagnosedDate.trim() === '') {
    return res.status(400).send("Please provide a valid diagnosed date.");
  }

  const sql = `INSERT INTO special_conditions (user_id, condition1, description, diagnosed_on)
               VALUES (?, ?, ?, ?)`;
  db.query(sql, [req.session.userId, condition, description, diagnosedDate], (err) => {
    if (err) throw err;
    res.redirect('/self-health/conditions');
  });
});

// Current Medications & Reminders
app.get('/self-health/medications', (req, res) => {
  res.render('self/medications_reminders');
});
app.post('/self-health/medications', (req, res) => {
  const { medication_name, dosage, frequency, reminder_date, reminder_time, notify_by } = req.body;
  // Save to DB
  res.redirect('/self-health/medications');
});




// Route to show baby vaccination schedule


 // your MySQL connection

// Show Vaccination Schedule
// Show Vaccination Schedule (GET)
app.get('/baby/:id/vaccination-schedule', (req, res) => {
  const accountId = req.params.id;

  db.query(
    'SELECT * FROM vaccination_records WHERE account_id = ?',
    [accountId],
    (err, results) => {
      if (err) {
        console.error('Error fetching records:', err);
        return res.status(500).send('Database error');
      }

      res.render('vaccination_schedule', {
        accountId: accountId,
        records: results
      });
    }
  );
});

// Mark vaccine (POST)
app.post('/mark-vaccine', (req, res) => {
  const { accountId, vaccineName, weekDue, status } = req.body;

  db.query(
    'SELECT * FROM vaccination_records WHERE account_id = ? AND vaccine_name = ? AND week_due = ?',
    [accountId, vaccineName, weekDue],
    (err, results) => {
      if (err) {
        console.error('Error querying:', err);
        return res.status(500).json({ success: false, message: 'Query failed' });
      }

      if (results.length > 0) {
        // Record exists - update
        db.query(
          'UPDATE vaccination_records SET status = ?, taken_at = NOW() WHERE id = ?',
          [status, results[0].id],
          (err) => {
            if (err) {
              console.error('Error updating:', err);
              return res.status(500).json({ success: false, message: 'Update failed' });
            }

            res.json({ success: true });
          }
        );
      } else {
        // Record doesn't exist - insert
        db.query(
          'INSERT INTO vaccination_records (account_id, vaccine_name, week_due, status, taken_at) VALUES (?, ?, ?, ?, NOW())',
          [accountId, vaccineName, weekDue, status],
          (err) => {
            if (err) {
              console.error('Error inserting:', err);
              return res.status(500).json({ success: false, message: 'Insert failed' });
            }

            res.json({ success: true });
          }
        );
      }
    }
  );
});

// Routes
const vaccinationRoutes = require('./routes/vaccination');
app.use('baby/:id/vaccination', vaccinationRoutes);

// In your route for vaccination schedule (e.g., /baby/vaccination/:accountId)
const moment = require('moment');

app.get('/baby/vaccination/:accountId', async (req, res) => {
  const accountId = req.params.accountId;
  const connection = await db.getConnection();

  try {
    // Get baby's birth date
    const [accounts] = await connection.query("SELECT dob FROM accounts WHERE id = ?", [accountId]);
    const dob = accounts[0].dob;

    // Get existing vaccine records
    const [records] = await connection.query("SELECT * FROM vaccination_records WHERE account_id = ?", [accountId]);

    const today = moment();
    const birthDate = moment(dob);

    // Auto-generate records for vaccines whose due date has passed
    const vaccines = getNationalImmunizationSchedule(); // define this same array as in your frontend
    const newRecords = [];

    vaccines.forEach(vaccine => {
      vaccine.weeks.forEach(weekStr => {
        const dueDate = calculateDueDateFromBirth(birthDate, weekStr);
        if (today.isAfter(dueDate)) {
          const exists = records.find(r => r.vaccine_name === vaccine.name && r.week_due === weekStr);
          if (!exists) {
            newRecords.push([accountId, vaccine.name, weekStr, 'taken']);
          }
        }
      });
    });

    // Bulk insert newly auto-marked vaccines
    if (newRecords.length > 0) {
      await connection.query("INSERT INTO vaccination_records (account_id, vaccine_name, week_due, status) VALUES ?", [newRecords]);
    }

    // Fetch updated records
    const [updatedRecords] = await connection.query("SELECT * FROM vaccination_records WHERE account_id = ?", [accountId]);

    res.render('vaccination_schedule', { accountId, records: updatedRecords });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  } finally {
    connection.release();
  }
});
function calculateDueDateFromBirth(birthDate, weekStr) {
  const m = birthDate.clone();

  if (weekStr.includes('At birth')) return m;
  if (weekStr.includes('weeks')) {
    const weeks = parseInt(weekStr);
    return m.add(weeks, 'weeks');
  }
  if (weekStr.includes('months')) {
    const months = parseInt(weekStr);
    return m.add(months, 'months');
  }
  if (weekStr.includes('years')) {
    const years = parseFloat(weekStr); // to handle 2.5 years
    return m.add(years, 'years');
  }
  return m; // fallback
}
app.post('/mark-vaccine', (req, res) => {
  const { accountId, vaccineName, weekDue, status } = req.body;

  db.query(
    'SELECT * FROM vaccination_records WHERE account_id = ? AND vaccine_name = ? AND week_due = ?',
    [accountId, vaccineName, weekDue],
    (err, results) => {
      if (err) {
        console.error('Error querying:', err);
        return res.status(500).send('Database query error');
      }

      if (results.length > 0) {
        // Update existing record
        db.query(
          'UPDATE vaccination_records SET status = ? WHERE account_id = ? AND vaccine_name = ? AND week_due = ?',
          [status, accountId, vaccineName, weekDue],
          (err2) => {
            if (err2) {
              console.error('Update error:', err2);
              return res.status(500).send('Error updating record');
            }
            res.redirect(`/baby/${accountId}/vaccination-schedule`);
          }
        );
      } else {
        // Insert new record
        db.query(
          'INSERT INTO vaccination_records (account_id, vaccine_name, week_due, status) VALUES (?, ?, ?, ?)',
          [accountId, vaccineName, weekDue, status],
          (err3) => {
            if (err3) {
              console.error('Insert error:', err3);
              return res.status(500).send('Error inserting record');
            }
            res.redirect(`/baby/${accountId}/vaccination-schedule`);
          }
        );
      }
    }
  );
});
