const express = require('express');
const router = express.Router();
const db = require('../db');

// Save vaccine as taken
router.post('/mark', (req, res) => {
  const { username, vaccine_name, schedule_week, is_taken } = req.body;
  const sql = `INSERT INTO vaccinations (username, vaccine_name, schedule_week, is_taken)
               VALUES (?, ?, ?, ?)
               ON DUPLICATE KEY UPDATE is_taken = ?`;
  db.query(sql, [username, vaccine_name, schedule_week, is_taken, is_taken], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send('Marked as taken');
  });
});

// Get history
router.get('/history/:username', (req, res) => {
  const username = req.params.username;
  db.query('SELECT * FROM vaccinations WHERE username = ?', [username], (err, results) => {
    if (err) return res.status(500).send(err);
    res.render('history', { records: results });
  });
});

module.exports = router;
