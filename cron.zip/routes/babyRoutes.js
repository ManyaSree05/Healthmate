const express = require('express');
const router = express.Router();
const db = require('../db'); // Adjust path if needed

// Show vaccination schedule
router.get('/:id/vaccination-schedule', (req, res) => {
  const accountId = req.params.id;

  db.query(
    'SELECT * FROM baby_vaccination_schedule WHERE account_id = ?',
    [accountId],
    (err, results) => {
      if (err) {
        console.error('DB error:', err);
        return res.status(500).send('Database error');
      }

      res.render('vaccination_schedule', { accountId, records: results });
    }
  );
});

// Update vaccine status
router.post('/mark-vaccine', (req, res) => {
  const { accountId, vaccineName, weekDue, status } = req.body;
  const isTaken = status === 'taken';

  db.query(
    'SELECT * FROM baby_vaccination_schedule WHERE account_id = ? AND vaccine_name = ? AND scheduled_week = ?',
    [accountId, vaccineName, weekDue],
    (err, results) => {
      if (err) {
        console.error('Error checking record:', err);
        return res.status(500).json({ success: false });
      }

      if (results.length > 0) {
        db.query(
          'UPDATE baby_vaccination_schedule SET is_taken = ?, taken_on = NOW() WHERE id = ?',
          [isTaken, results[0].id],
          (err2) => {
            if (err2) {
              console.error('Update error:', err2);
              return res.status(500).json({ success: false });
            }
            res.json({ success: true });
          }
        );
      } else {
        db.query(
          'INSERT INTO baby_vaccination_schedule (account_id, vaccine_name, scheduled_week, is_taken, taken_on) VALUES (?, ?, ?, ?, NOW())',
          [accountId, vaccineName, weekDue, isTaken],
          (err3) => {
            if (err3) {
              console.error('Insert error:', err3);
              return res.status(500).json({ success: false });
            }
            res.json({ success: true });
          }
        );
      }
    }
  );
});

module.exports = router;
